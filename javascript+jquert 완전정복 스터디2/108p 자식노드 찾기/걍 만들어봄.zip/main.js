$(document).ready(function(){
    ListHover();
    slideEvent();
});

function ListHover() {
    var $main_list = $(".menu_box > ul > li");

    $main_list.hover(
        function() {
            $(this).find(".sub_menu").stop().slideDown(200);
        },
        function() {
            $(this).find(".sub_menu").stop().slideUp(200);
        }
    )
}


function slideEvent() {
    var $left = $("#left_btn");
    var $right = $("#right_btn");
    var $slide = $(".slide");
    var count = 0;
    var $slide_bool = true;

    function right(){
        $right.on("click", function(){
            if($slide_bool && count < $slide.length - 1) {
                $slide_bool = false;
                count++;
                $slide.animate({
                    left : - $slide.width() * count
                }, 1000, function(){
                    $slide_bool = true;
                });
            }
        });
    }
    right();

    function left() {
        $left.on("click", function(){
            if($slide_bool && count > 0){
                $slide_bool = false;
                count--;
                $slide.animate({
                    left : - $slide.width() * count
                },1000 , function(){
                    $slide_bool = true;
                });
            }
        });
    }
    left();
}



