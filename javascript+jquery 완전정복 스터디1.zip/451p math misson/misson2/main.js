let btnStart = $("#btnStart");
let fish = $("#fish");
let fish_count_p = $("#fish_count");
let fish_count = 0
let count = 0;
let x = 0;
let y = 0;
let timerID = 0;

$(document).ready(function(){
    fishMove();
    fishClickInit();
    fishStartBtn();
});


function fishMove(){
    timerID = setInterval(function(){

        count++;
        x = Math.floor(Math.random() * 680) + 120;
        y = Math.floor(Math.random() * 520) + 70;

        fish.css({
            left : x,
            top : y
        });

        if(count == 10){
            clearInterval(timerID);
            count = 0;
            timerID = 0;
        }
        console.log(timerID);
        
    },1000);
    
}

function fishClickInit(){
    if(timerID != 0) {
        fishEvent();
    }
}

function fishEvent(){
    fish.on("click", function(){
        fish_count++;
        fish_count_p.text(fish_count);
    });
}

function fishStartBtn() {
    btnStart.on("click", function(){
        if(timerID == 0){
            fishMove();
        } else if(timerID != 0){
            console.log("timerID의 동작이 끝나지 않았습니다.");
        }
    });
}